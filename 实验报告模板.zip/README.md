# 实验报告 
%！主要参考了 清华大学近代物理实验模板（非官方） 
ICExample.cls 模板格式配置文件

ICExample.tex 正文内容

ICExample.bib 参考文献

image 文件夹下是正文中用到的图片文件